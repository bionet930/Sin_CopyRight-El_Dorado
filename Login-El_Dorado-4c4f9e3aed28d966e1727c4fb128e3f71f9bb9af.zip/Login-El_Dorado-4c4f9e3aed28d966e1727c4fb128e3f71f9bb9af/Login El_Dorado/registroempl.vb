﻿Public Class registroempl

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub btnsalirempl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsalirempl.Click
        Me.Close()
    End Sub

   
End Class