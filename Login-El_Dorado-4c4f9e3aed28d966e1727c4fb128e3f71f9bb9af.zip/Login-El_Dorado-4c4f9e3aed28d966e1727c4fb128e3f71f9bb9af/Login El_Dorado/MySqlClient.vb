﻿
Namespace MySql.Data
    Class MySqlClient

    End Class
End Namespace
