﻿
Namespace consulta
    Class mostrarEnTabla

        Private _p1 As String

        Sub New(ByVal p1 As String)
            ' TODO: Complete member initialization 
            _p1 = p1
        End Sub

    End Class
End Namespace
